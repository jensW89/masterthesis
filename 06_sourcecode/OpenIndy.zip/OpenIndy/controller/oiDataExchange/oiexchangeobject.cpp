#include "oiexchangeobject.h"

oiExchangeObject::oiExchangeObject(QObject *parent) :
    QObject(parent)
{

    device = NULL;


}
