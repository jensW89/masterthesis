#ifndef TYPES_H
#define TYPES_H

#include "laarmadillo.h"

typedef LAArmadillo LAAlgorithm;

#endif // TYPES_H
